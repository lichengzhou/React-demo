/**
 * Created by kee on 15/9/25.
 */
// import http from 'http';
// import koa from 'koa';
// import serve from 'koa-static';
// import Router from 'koa-router';
// import render from 'koa-ejs';
// import cors from 'koa-cors';
// import parser from 'koa-bodyparser';
// import logger from 'koa-logger';
// import compress from 'koa-compress';
// import path from 'path';



//exports = module.exports = server;

//import api from './api'
const http = require("http");
const koa = require("koa");
const serve = require("koa-static");
const Router = require("koa-router");
const cors = require("koa-cors");
const parser = require("koa-bodyparser");
const logger = require("logger");
const path = require("path");
var orientdb = require('node-orientdb-http');


var db = orientdb.connect({
  host: "http://localhost:2480",
  user: "root",
  password: "vipabc",
  database: "lpgs-development"
});

db.on('connect', function() {
  console.log("connect");
});

db.on('error', function(err) {
  // mmm error ..
  console.log("connect fail");
});

const app = koa();
app.experimental = true;
app.use(cors());
app.use(parser());

app.use(function(){
	
});
const api = require('./api');
app.use(api(Router));

app.on('error', error=>{
  console.error(error);
});

const server = http.createServer(app.callback());

server.listen(3000, '127.0.0.1', ()=>{
  console.log('server listen');
});


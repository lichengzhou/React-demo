"use strict";
const debug = require('debug')('vipabc:lpgs:IndexController');

const url = require('url');
const moment = require('moment');
require('moment/locale/zh-cn');
const request = require('request');

exports = module.exports = function controller(app) {

  app.group('', function(router) {
    router.get('/index', function*(next) {

      this.render('index', {
        title: 'fuck you'
      });
    });
  });
};

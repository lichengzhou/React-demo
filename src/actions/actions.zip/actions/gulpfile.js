var gulp = require("gulp"),
  rename = require('concur-gulp-rename'),
  webpack = require('webpack-stream'),
  fs = require('fs'),
  path = require('path'),
  gzip = require('gulp-gzip'),
  rm = require('gulp-rm');

process.env.NODE_ENV = process.env.NODE_ENV || "development";

function getFolders(dir) {
  return fs.readdirSync(dir)
    .filter(function(file) {
      return fs.statSync(path.join(dir, file)).isDirectory();
    });
}

var watchMode = false;
gulp.task('webpack', ['clean'], function() {
  return gulp.src("webpack.config.js")
    .pipe(webpack(require('./webpack.config.js'), require('webpack')))
    .pipe(gulp.dest('public'));
});

gulp.task('build', ['webpack']);
gulp.task('clean', function(cb) {
  return gulp.src('./public/**/*', {
      read: false
    })
    .pipe(rm())
});
gulp.task('cleangz', function(cb) {
  return gulp.src('./public/**/*.gz', {
      read: false
    })
    .pipe(rm())
});
gulp.task('default', ['build']);
gulp.task('buildgz', ['build'], function() {
  return gulp.src('public/**/!(*.gz|*.png|*.jpg|*.jpeg|*.svg)') // png and jpg already very well compressed, might even make it larger
    .pipe(require('gulp-size')({
      showFiles: true
    }))
    .pipe(gzip({
      gzipOptions: {
        level: 9
      }
    }))
    .pipe(rename({
      extname: ".gz"
    }))
    .pipe(require('gulp-size')({
      showFiles: true
    }))
    .pipe(gulp.dest('public'));
});

gulp.task('httpServer', function() {
  process.env.RUNNING = "local";
  var App = require('./index.js');
  var HTTPServer = new App();
  HTTPServer.start(function() {
    console.log('info', 'server listening');
  });
});
gulp.task('server', ['httpServer', 'build'], function() {
  require('core-js/fn/object/assign');
  const webpack = require('webpack');
  const WebpackDevServer = require('webpack-dev-server');
  const config = require('./webpack.config');

  return new WebpackDevServer(webpack(config), config.devServer)
    .listen(config.port, 'localhost', (err) => {
      if (err) {
        console.log(err);
      }
      console.log('Listening at localhost:' + config.port);
      console.log('Opening your system browser...');
    });
  // return gulp.watch(['app/assets/**', 'app/View/**'], ["cleangz", "build"]);
});

gulp.task("backendServer", function(){
    
});
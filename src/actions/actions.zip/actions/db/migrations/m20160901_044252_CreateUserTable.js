"use strict";
exports.name = "CreateUserTable";

exports.up = function (db) {
  // @todo implementation
};

exports.down = function (db) {
  // @todo implementation
};


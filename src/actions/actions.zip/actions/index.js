"use strict"
const Leaf = require('leafjs');
const Http = Leaf.http;
const orientMw = require('leaf-orient');
const fs = require('fs');

class Lpgs extends Http {
	constructor() {
		super(module);
		this.ORM = orientMw.ORM;
	}
	bootstrap() {
		this.use(orientMw);
		this.koa.use(function*() {

		})
	}

}

exports = module.exports = Lpgs;
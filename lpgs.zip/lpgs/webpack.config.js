var env = process.env.NODE_ENV || "development";
var readYaml = require('read-yaml');
var config = readYaml.sync('./config/server.yml')[env];
if (!config) {
    throw `./config/server.yml#${env} is required`
}

var srcPath = require('path').join(__dirname, './app/assets/src/');;

module.exports = options = {
    debug: true,
    devtool: 'eval-source-map',
    port: 8000,
    entry: ['webpack-dev-server/client?http://127.0.0.1:8000',
        'webpack/hot/only-dev-server',
        './app/assets/src/index'
    ],
    output: {
        publicPath: "/public/",
        path: require('path').resolve(process.cwd() + "/public"),
        filename: "app.js"
    },
    devtool :"source-map",
    devServer: {
        contentBase: './app/assets/src/',
        historyApiFallback: true,
        hot: true,
        port: 8000,
        publicPath: "/public/",
        noInfo: false,
        host:'0.0.0.0',
        proxy: {
            // "http://localhost:8000/api/*": "http://localhost:3000/api/*",
            // "http://192.168.111.237:8000/*": "http://localhost:8000/*",
            // // '*': {
            //     target: '127.0.0.1:8000',
            //     secure: false,
            // }
        }
    },
    resolve: {
        extensions: ['', '.js', '.jsx'],
        alias: {
            actions: `${srcPath}actions`,
            components: `${srcPath}components`,
            sources: `${srcPath}sources`,
            stores: `${srcPath}stores`,
            styles: `${srcPath}styles`,
            config: `${srcPath}config` + process.env.REACT_WEBPACK_ENV
        },
        modulesDirectories: ["lib", "node_modules", "app/assets", "node_modules/leafjs", "app/View"]
    },
    module: {
        preLoaders: [{
            test: /\.jsx?$/,
            loaders: process.env.NODE_ENV === 'production' ? [] : ['eslint'],
            include: srcPath
        }],
        loaders: [{
            test: /\.(js|jsx)$/,
            loader: 'react-hot!babel-loader',
            include: srcPath,
            exclude: /node_modules/
        }, {
            test: /\.css$/,
            loader: "style-loader!css-loader!postcss-loader"
        }, {
            test: /\.scss$/,
            loaders: "style-loader!css-loader!postcss-loader!sass-loader?outputStyle=expanded&indentedSyntax"
        }, {
            test: /\.(mp4|ogg|svg)$/,
            loader: 'file-loader'
        }, {
            test: /\.svg(\#.*)?$/,
            loader: "url?limit=8192"
        }, {
            test: /\.woff(\?v=\d+\.\d+\.\d+)?$/,
            loader: "url?limit=8192&minetype=application/font-woff"
        }, {
            test: /\.woff2(\?v=\d+\.\d+\.\d+)?$/,
            loader: "url?limit=8192&minetype=application/font-woff"
        }, {
            test: /\.ttf(\?v=\d+\.\d+\.\d+)?$/,
            loader: "url?limit=8192&minetype=application/octet-stream"
        }, {
            test: /\.eot(\?v=\d+\.\d+\.\d+)?$/,
            loader: "file"
        }, {
            test: /\.(gif|png|jpe?g)(\?.*)?$/,
            loader: "url?limit=8192!image!image-maxsize" + (process.env.SKIP_MAXSIZE === "true" ? "?skip" : "")
        }, {
            test: /\.yml$/,
            loader: "yaml"
        }, {
            test: /\.json$/,
            loader: "json-loader"
        }]
    },
};
var webpack = require('webpack');

options.plugins = options.plugins || [];
options.plugins.push(new webpack.optimize.OccurenceOrderPlugin());
options.plugins.push(new webpack.HotModuleReplacementPlugin());
options.plugins.push(new webpack.NoErrorsPlugin());

if (env === "production") {
    options.debug = false;
    options.plugins.push(new webpack.optimize.UglifyJsPlugin({
        compress: {
            warnings: false
        }
    }));
}
exports = module.exports = function(Router) {
  const router = new Router({
    prefix: '/api'
  });

  router.get('/pageLists',  function() {
    console.log("q");
    try {
      const posts = {'name':"124"};
      this.body = {
        posts: posts,
        msg: 'ok'
      };
    }catch (e) {
      this.body = {
        error: 'error'
      };
    }
  });

  router.get('/page',  function () {
    console.log("q");
    try {
      const posts = {'name':"14"};
      this.body = {
        posts: posts,
        msg: 'ok'
      };
    }catch (e) {
      this.body = {
        error: 'error'
      };
    }
  });

  router.get('/',  function() {
    console.log("q");
    try {
      const posts = {'name':"14"};
      this.body = {
        posts: posts,
        msg: 'ok'
      };
    }catch (e) {
      this.body = {
        error: 'error'
      };
    }
  });
  return router.routes();
};




"use strict";
var debug = require('debug')('vipabc:Datamap:LeadsService'),
  Promise = require('bluebird');

var request = require('request');
var readYaml = require('read-yaml');
var path = require('path');

var app, config;

class LeadsService {
  constructor(app) {
    app = app;
    // config = readYaml.sync(path.resolve(app.basepath,"./config/lead-services.yml"))[process.env.NODE_ENV.toLowerCase()];
  }
  // getTopBanner(limit, belonging, startTime, endTime) {
  //   return new Promise(function(resolve,reject) {
  //     request.get(config.LoadTopBanner, { form:{ topCount: limit, Belonging: belonging, startTime: startTime, endTime: endTime}, json:true}, function optionalCallback(error, response, result) {
  //       if (!error && response.statusCode == 200) {
  //         var leads = JSON.parse(result.JsonResult);
  //         resolve(leads);
  //       } else {
  //         reject(error);
  //       }
  //     });
  //   });
  // }

  // getLeadsRankByCity(params) {
  //   return new Promise(function(resolve,reject) {
  //     request.get(config.GetLeadsRankByCity + `?Type=${params.type}&StartTime=${params.startTime}&EndTime=${params.endTime}&Channel=&City=&TopNum=${params.topNum}`, {json:true}, function optionalCallback(error, response, result) {
  //       if (!error && response.statusCode == 200) {
  //         var leads = JSON.parse(result.JsonResult);
  //         resolve(leads);
  //       } else {
  //         reject(error);
  //       }
  //     });
  //   });
  // }
}

exports = module.exports = LeadsService;
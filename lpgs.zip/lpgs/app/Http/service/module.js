exports = module.exports = function(Router, db) {
  const router = new Router({
    prefix: '/api'
  });

  //查询sql拼装
  function qureyData(tableName, params){
      let condition = "";
      if(params){
        for(let i in params){
          if(condition){
            condition += " and ";
          }
          if(params.hasOwnProperty(i) === true){
            condition = condition + i + "=" + JSON.stringify(params[i]);
          }
        }
      }
      
      let temp = "select * from " + tableName ;
      if(condition && condition.length > 0){
        temp = temp + " where " + condition;
      }
      return db.query(temp).then(function(data){
        return data;
      }, function(err){
        throw new Error(err);
      });
  }

  //新增数据
  function addData(tableName, params){
    if(!params){
       throw new Error("The params is null.");
    }
    else{
      let condition = '';
      if(params){
        condition += 'id=format(\"%s\",uuid())';
        for(let i in params){
            condition += ' , ';
          if(params.hasOwnProperty(i) === true){
            condition = condition + i + '=' + JSON.stringify(params[i]);
          }
        }
      }
      
      let temp = 'insert into ' + tableName + ' set ' + condition ;
      console.log(temp);
      return db.command(temp).then(function(data){
        return true;
      }, function(err){
        throw new Error(err);
      });
    }
  }

  //更新数据
  function qureyData(tableName, params){
      let condition = "";
      if(params){
        for(let i in params){
          if(condition){
            condition += " and ";
          }
          if(params.hasOwnProperty(i) === true){
            condition = condition + i + "=" + JSON.stringify(params[i]);
          }
        }
      }
      
      let temp = "select * from " + tableName ;
      if(condition && condition.length > 0){
        temp = temp + " where " + condition;
      }
      return db.query(temp).then(function(data){
        return data;
      }, function(err){
        throw new Error(err);
      });
  }

  router.get('/moduleList',  (async function(){
    try {
      let that = this;
      let data  = await qureyData("module").then(function(data){
        return  data;
      }, function(error){});
      this.body = {
        data: data,
        status:true,
        msg: 'ok'
      };
    }catch (e) {
      console.log("error");
      this.body = {
        error: 'error'
      };
    }
  }));

  router.get('/addModule',  async function() {
    try {
      let flag = false;
      let params = {
        name:"third",
        theme:"allow",
        templateid:"4",
        header_param:'{title:"www"}'
      };

      await addData("module", params).then(function(data){
        console.log("success");
        flag = data;
      }, function(err){
        console.log("添加数据失败！");
        throw new Error("添加数据失败！");
      });

      this.body = {
        data:flag,
        status:true,
        msg:""
      };
    }catch (e) {
      this.body = {
        error: 'error'
      };
    }
  });

  router.get('/updateModule',  async function() {
    try {
      let flag = false;
      let params = {
         id:"232e24f1-f878-47b1-9f0c-40b9a7eeff85",
         name:"user",
         theme:"23d"
      };
      await updateData("module", params).then(function(data){
        flag = data;
      }, function(err){
        throw new Error("修改数据失败！");
      });

      this.body = {
        data:flag,
        msg:""
      };
    }catch (e) {
      this.body = {
        error: 'error'
      };
    }
  });

  //删除数据
  router.get('/deleteModule',  async function() {
    try {
      let flag = false;
      let params = {
          id:1
      };
      let condition = "delete from module where id = " + JSON.stringify(params.id);
      await db.command(condition).then(function(data){
        flag = true;
      }, function(error){
        throw new Error("删除数据失败！");
      });
      
      this.body = {
        data:flag,
        msg:""
      };
    }catch (e) {
      this.body = {
        error: 'error'
      };
    }
  });

  return router.routes();
};




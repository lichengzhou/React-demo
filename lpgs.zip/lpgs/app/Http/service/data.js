exports = module.exports = function(Router, db) {
  const router = new Router({
    prefix: '/api'
  });

  //查询sql拼装
  function qureyData(tableName, params){
      let condition = "";
      if(params){
        for(let i in params){
          if(condition){
            condition += " and ";
          }
          if(params.hasOwnProperty(i) === true){
            condition = condition + i + "=" + JSON.stringify(params[i]);
          }
        }
      }
      
      let temp = "select * from " + tableName ;
      if(condition && condition.length > 0){
        temp = temp + " where " + condition;
      }
      return db.query(temp).then(function(data){
        return data;
      }, function(err){
        throw new Error(err);
      });
  }

  //新增数据
  function addData(tableName, params){
    if(!params){
       throw new Error("The params is null.");
    }
    else{
      let condition = '';
      if(params){
        condition += 'id=format(\"%s\",uuid())';
        for(let i in params){
            condition += ' , ';
          if(params.hasOwnProperty(i) === true){
            condition = condition + i + '=' + JSON.stringify(params[i]);
          }
        }
      }
      
      let temp = 'insert into page set ' + condition ;
      console.log(temp);
      return db.command(temp).then(function(data){
        return true;
      }, function(err){
        throw new Error(err);
      });
    }
  }

  //更新数据
  function updateData(tableName, params){
    if(!params){
       throw new Error("The params is null.");
    }
    else{
      let temp, condition="";
      for(let i in params){
        if(condition){
          condition += " , ";
        }
        condition = condition + i + "=" + JSON.stringify(params[i]);
      }

      temp = "update " + tableName + " set " + condition + " where id=" + JSON.stringify(params.id);
      console.log(temp);
      return db.command(temp).then(function(data){
        console.log(data);
        return true;
      }, function(err){
        throw new Error(err);
      });

    }
  }
  router.get("/test", async function(){
    let data = await db.command("insert into page set id=format(\"%s\",uuid()) , name='we'")
      .then(function(data){console.log(data);return data}, function(err){console.log(err);return err;});
      this.body = {
        data:data,
        msg:""
      };
  })

  router.get('/pageList',  (async function(){
    try {
      let that = this;
      let data  = await qureyData("page").then(function(data){
        return  data;
      }, function(error){});
      this.body = {
        data: data,
        msg: 'ok'
      };
    }catch (e) {
      console.log("error");
      this.body = {
        error: 'error'
      };
    }
  }));

  router.get('/addPageData',  async function() {
    try {
      let flag = false;
      let params = {
        name:"third",
        theme:"allow",
        templateid:"4",
        header_param:'{title:"www"}'
      };

      await addData("page", params).then(function(data){
        console.log("success");
        flag = data;
      }, function(err){
        console.log("添加数据失败！");
        throw new Error("添加数据失败！");
      });

      this.body = {
        data:flag,
        msg:""
      };
    }catch (e) {
      this.body = {
        error: 'error'
      };
    }
  });

  router.get('/updatePageData',  async function() {
    try {
      let flag = false;
      let params = {
         id:"232e24f1-f878-47b1-9f0c-40b9a7eeff85",
         name:"user",
         theme:"23d"
      };
      await updateData("page", params).then(function(data){
        flag = data;
      }, function(err){
        throw new Error("修改数据失败！");
      });

      this.body = {
        data:flag,
        msg:""
      };
    }catch (e) {
      this.body = {
        error: 'error'
      };
    }
  });

  //删除数据
  router.get('/deletePageData',  async function() {
    try {
      let flag = false;
      let params = {
          id:1
      };
      let condition = "delete from page where id = " + JSON.stringify(params.id);
      await db.command(condition).then(function(data){
        flag = true;
      }, function(error){
        throw new Error("删除数据失败！");
      });
      
      this.body = {
        data:flag,
        msg:""
      };
    }catch (e) {
      this.body = {
        error: 'error'
      };
    }
  });

  return router.routes();
};




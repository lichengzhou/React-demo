// index.js 
// 用于引入babel，并且启动app.js

require("babel-core/register");
require("babel-polyfill");
require("./app");
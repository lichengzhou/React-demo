/**
 *页面管理
 * 页面管理页面
 */
require('styles/common/bootstrap.min.css');
require('styles/common/common.css');
require('styles/page.css');

import React from 'react';
import {withRouter } from 'react-router';
import $ from 'jquery';
import Header from './PageHeader';
import PageSearch from './PageSearch';
import TopTitle from './PageTopTitle';
import PageDataItem from './PageDataItem';
import ModuleDataItem from './PageTemplateDataItem';
import CreatePage from './PageCreate';
import PageToTemplate from './PageToTemplate';
import PageTemplateProp from './PageTemplateProp';
import {postData, getData} from '../actions/Common';


//页面管理页面
class PageContainer extends React.Component{
	constructor(props){
		super(props);
		this.state={displayStyle:{display:'none'}, pageStyle:{display:'block'},
			moduleStyle:{display:'none'}, pageDataList:this.props.dataList,
			initValue:{titleInfo:'Create Page',name:"", title:"", linke:"",catagory:"0",responsive:"0"}
		};
		this.addPage = this.addPage.bind(this);
		this.close = this.close.bind(this);
		this.save = this.save.bind(this);
		this.pageSelected = this.pageSelected.bind(this);
		this.dealPageDataItem.bind(this);
		this.updateCondition.bind(this);
		this.getPageDataList.bind(this);
	}
	
	getUrlList(data){
		this.setState({pageDataList:data});
		localStorage.setItem("pageList", JSON.stringify(data));
	}

	queryPageList(){
		getData("http://localhost:3000/api/pageList", this.getUrlList.bind(this));
	}

	componentDidMount() {
		this.queryPageList();
	 }

	pageSelected(isTrue){
		if(isTrue){
			$(".condition .tab1").addClass("active").siblings().removeClass("active");
			this.setState({pageStyle:{display:'block'},moduleStyle:{display:'none'}});
		}
		else{
			$(".condition .tab2").addClass("active").siblings().removeClass("active");
			this.setState({pageStyle:{display:'none'},moduleStyle:{display:'block'}});
		}
		
	}
	addPage(){
		let initValue={titleInfo:'Create Page',name:"", title:"", linke:"",catagory:"0",responsive:"0", edit:false};
		document.querySelector("#create-page").style.display = "block";
		this.setState({initValue: initValue});
	}
	editPageInfo(itemValue, titleInfo){
		let initValue = {};
		initValue.titleInfo = titleInfo || "Edit Page Information";
		initValue.name = itemValue.name;
		initValue.title = typeof itemValue.headerParam == 'Object' ? itemValue.headerParam.title : "";
		initValue.link = itemValue.link;
		initValue.catagory = itemValue.catagory;
		initValue.responsive = itemValue.responsive;
		initValue.type = itemValue.type;
		initValue.header_param = itemValue.header_param;
		initValue.id = itemValue.id;
		initValue.edit = true;
		this.setState({initValue: initValue});
	}
	close(){
		document.querySelector("#create-page").style.display = "none";
	}
	save(itemData){
		let newValue = {};
		newValue.header_param = {};
		newValue.name = document.querySelector(".prop-new #name").value;
		newValue.title = document.querySelector(".prop-new #title").value;
		newValue.link = document.querySelector(".prop-new #netValue").innerText;
		let catagoryDom = document.querySelector(".prop-new #catagory");
		let selectedIndex = catagoryDom.selectedIndex;
		newValue.catagory = catagoryDom.options[selectedIndex].value;
		// let reaponsiveDom = document.querySelectorAll(".prop-new [name='type']");
		// let responsive;
		// for(let i = 0; i < reaponsiveDom.length; i++){
		// 	if(reaponsiveDom[i].checked){
		// 		responsive = reaponsiveDom[i].value;
		// 	}
		// }
		let responsiveDom = document.querySelector(".prop-new #catagory");
		let selectedresponsive = responsiveDom.selectedIndex;
		newValue.responsive = responsiveDom.options[selectedresponsive].value;

		newValue.header_param.shareImg = document.querySelector(".prop-new #shareImg").value;
		newValue.header_param.shareTitle = document.querySelector(".prop-new #shareTitle").value;
		let shareDescription = document.querySelector(".prop-new #shareDescription").value;
		if(shareDescription){
			newValue.header_param.shareDescription = document.querySelector(".prop-new #shareDescription").value;
		}
		if(itemData && itemData.id){
			newValue.id = itemData.id;
			let id = itemData.id;
			postData("http://localhost:3000/api/updatePageData", newValue, function(data){
				if(data.status){
					document.querySelector("#create-page").style.display = "none";
					querySelectorAll();
				}
			});
		}
		else{
			postData("http://localhost:3000/api/addPageData", newValue, function(data){
				if(data.status){
					document.querySelector("#create-page").style.display = "none";
					querySelectorAll();
					console.log(data.data);
					//this.props.router.push("/createPage/" + data.data.id);
				}
			});
		}
		//document.querySelector("#create-page").style.display = "none";
		
	}
	//过滤数据
	dealPageDataItem(pageDataList, itemValue, theme, catagory, keywords, status, type){
		pageDataList = pageDataList || [];
		let flag = true;
		if(theme && itemValue.theme != theme){
			flag = false;
		}

		if(flag && catagory && itemValue.catagory != catagory){
			flag = false;
		}

		if(flag && keywords && itemValue.name.indexOf(keywords) == -1){
			flag = false;
		}

		if(flag && status && status.indexOf(itemValue.status) > -1){
			flag = true;
		}
		else if(flag && itemValue.status == "1"){
			flag = true;
		}
		else{
			flag = false;
		}

		let statusValue = itemValue.status;
		let themeValue = itemValue.catagory;
		if(statusValue == "0"){
			itemValue.statusDescription = "draft";
		}
		else if(statusValue == "1"){
			itemValue.statusDescription = "release";
		}
		else if(statusValue == "2"){
			itemValue.statusDescription = "expired";
		}

		if(themeValue == "0"){
			itemValue.tag = "vipabc";
		}
		else if(themeValue == "1"){
			itemValue.tag = "vipabc junior";
		}
		else if(themeValue == "2"){
			itemValue.tag = "TotorABC";
		}
		else if(themeValue == "3"){
			itemValue.tag = "TotorABC jr";
		}
		if(flag){
			pageDataList.push(itemValue);
		}
		return itemValue;
	}

	//获取页面主题，vipabc，vipabc junior等
	updateCondition(){
		let {pageDataList} = this.getPageDataList();
		// localStorage.setItem("pagelist", this.state.pageDataList);
		this.setState({pageDataList:pageDataList});
	}
	page2Template(itemValue){
		let initValue = itemValue;
		initValue.titleInfo = "Edit Template Information";
		this.setState({initValue:initValue});
	}
	getPageDataList(){
		let that = this;
		let conditionValue = JSON.parse(localStorage.getItem("page.condition"));
		let defaultCondition = {theme:"0", catagory:"0", keywords:"", status:""};
		conditionValue = conditionValue || defaultCondition; 
		Object.assign(defaultCondition, conditionValue);
		let theme = defaultCondition.theme;
		let catagory = defaultCondition.catagory;
		let keywords = defaultCondition.keywords;
		let status = defaultCondition.status;
		// let type = document.querySelector(".switchTab button.active").getAttribute("data-type");
		//处理页面单个数据数据
		let dataList = this.state.pageDataList;
		let temp = localStorage.getItem("pageList");
		if(temp){
			let temp2 = JSON.parse(temp);
			if(temp2){
				dataList = temp2;
			}
		}

		let pageDataList = [];
		let moduleDataList = [];
		dataList.forEach(function(itemValue){
			that.dealPageDataItem(pageDataList, itemValue, theme, catagory, keywords, status);
		});
		pageDataList = pageDataList.map(itemValue => (<PageDataItem item={itemValue} key={itemValue.id} editPageInfo={this.editPageInfo.bind(this, itemValue, 'Edit Page Information')}/>));
		return {pageDataList, theme, catagory, keywords, status};
	}
	render(){
		let templateInfo = "Edit Template";
		let {pageDataList, theme, catagory, keywords, status} = this.getPageDataList();
		let moduleDataList = this.props.dataList.map(itemValue => (<ModuleDataItem item={itemValue} key={itemValue.id} editPageInfo={this.editPageInfo.bind(this, itemValue, templateInfo)} />));
		return (
			<div className="page">
				<Header updateCondition={this.updateCondition.bind(this)} defaultValue={theme} />
				<PageSearch addPage={this.addPage} pageSelected={this.pageSelected} updateCondition={this.updateCondition.bind(this)} keywords={keywords}/>
				<div className="wrap page" style={this.state.pageStyle}>
					<TopTitle updateCondition={this.updateCondition.bind(this)} catagroy={catagory} status={status}/>
					<ul>
						{pageDataList}
					</ul>
				</div>
				<div className="wrap module" style={this.state.moduleStyle}>
					<ul>
						{moduleDataList}
					</ul>
				</div>
				<CreatePage close={this.close} save={this.save} initValue={this.state.initValue}/>
				<PageToTemplate initValue={this.state.initValue}/>
				<PageTemplateProp initValue={this.state.initValue}/>
			</div>
		);
	}
}

var pageList = {dataList:[{id:1,name:"123首发 0利率1", theme:"0", headerParam:{}, templateid:"1", status:1, catagory:"0", layout_data:{}, 
							type:"0", layout_id:"",page_js:"", page_css:"", tag:"官网"},
			]};


PageContainer.defaultProps = {dataList: pageList.dataList};
PageContainer.propTypes = {
  router: React.PropTypes.shape({
    push: React.PropTypes.func.isRequired
  }).isRequired
};
var DecoratePageContainer = withRouter(PageContainer);
export default DecoratePageContainer;
//创建XML对象
function createXmlObject(){
	let xmlObject ;
	if (window.XMLHttpRequest) {
        xmlObject = new XMLHttpRequest();
    }
    else if (window.ActiveXObject) {
        xmlObject = new ActiveXObject("Msxml2.Xmlhttp");
    }

    return xmlObject;
}
//post请求数据
export function postData(url, params, callback, async){
	let xmlObject = createXmlObject();
	xmlObject.open("POST", url, !async ? true : async);
	xmlObject.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
	xmlObject.send("data=" + JSON.stringify(params));
	xmlObject.onreadystatechange = function() { 
		console.log(xmlObject.status+ ":"  + xmlObject.responseText);
		if (xmlObject.readyState == 4) {
			if(xmlObject.status == 200){
				if(callback){
					console.log("data:" + xmlObject.responseText);
				 	callback(xmlObject.responseText);
				 }
			}
			else { 
				//console.log(this.responseText);
			} 
		} 
	}
}

export function getData(url, callback){
	let xmlObject = createXmlObject();
	
	xmlObject.open("get", url);
	xmlObject.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
	xmlObject.send(null);
	xmlObject.onreadystatechange = function() { 
		if (xmlObject.readyState == 4) {
			if(xmlObject.status == 200){
				if(callback){
					let data = JSON.parse(xmlObject.responseText).data.result;
				 	callback(data);
				 }
			}
			else { 
			} 
		} 
	}
}



